-- ============================================
-- HEALO: admin_audit_logs.inquiry_ids 타입 수정
-- ============================================
-- 목적: UUID[] → INT4[]로 변경
-- 이유: public.inquiries.id는 integer (INT4)
-- ============================================

-- 기존 테이블이 UUID[]로 생성되었다면 INT4[]로 변경
DO $$
BEGIN
    -- inquiry_ids 컬럼 타입 확인 및 변경
    IF EXISTS (
        SELECT 1 
        FROM information_schema.columns 
        WHERE table_schema = 'public' 
        AND table_name = 'admin_audit_logs' 
        AND column_name = 'inquiry_ids'
    ) THEN
        -- 기존 데이터 백업 (optional, 데이터가 있을 경우)
        -- 타입 변경 (UUID[] → INT4[])
        ALTER TABLE public.admin_audit_logs 
        ALTER COLUMN inquiry_ids TYPE INT4[] 
        USING NULL;  -- 기존 UUID 데이터는 버림 (호환 불가)
        
        RAISE NOTICE 'admin_audit_logs.inquiry_ids type changed to INT4[]';
    END IF;
END $$;

-- 코멘트 업데이트
COMMENT ON COLUMN public.admin_audit_logs.inquiry_ids IS '✅ 조회된 inquiry ID 배열 (INT4[]) - public.inquiries.id 참조';

-- 검증 쿼리 (선택)
-- SELECT column_name, data_type, udt_name
-- FROM information_schema.columns
-- WHERE table_name = 'admin_audit_logs' AND column_name = 'inquiry_ids';
-- 
-- 예상 결과: data_type = 'ARRAY', udt_name = '_int4'
