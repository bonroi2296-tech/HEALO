# 병원 성과 기반 자동 학습 시스템

> 작성일: 2026-01-29  
> 목적: 데이터 기반 병원 추천 (LLM 파인튜닝 아님)  
> 방식: 베이지안 스무딩 기반 통계 랭킹

---

## 🎯 전체 개요

### 목표
- 병원 전달 결과를 학습하여 추천 품질 향상
- Cold Start 문제 해결 (신규 병원도 공정하게 평가)
- 데이터가 쌓일수록 정확도 향상

### 비목표
- ❌ LLM 파인튜닝 (비용/복잡도 높음)
- ❌ 자동 전송 (운영자 확인 필수)
- ❌ 실시간 추천 (배치 집계)

---

## 📊 데이터 흐름

```
1. 리드 전달
   inquiries → hospital_lead_assignments (어디로 보냈는지 기록)
   
2. 병원 응답
   hospital_responses (응답 상태 업데이트)
   
3. 성과 집계 (배치)
   refresh_hospital_performance_stats() 실행
   → hospital_performance_stats 업데이트
   
4. 추천 조회
   v_hospital_recommendations VIEW 사용
   → 베이지안 점수 기반 정렬
   
5. 운영자 선택
   추천 결과 참고하여 최종 결정
```

---

## 🧮 베이지안 스무딩 상세 설명

### 문제: 왜 단순 전환율로는 안 되는가?

#### 예시
```
병원 A: 100건 중 40건 전환 (40%)
병원 B: 2건 중 2건 전환 (100%)

단순 전환율 순위: B(100%) > A(40%)
실제 추천해야 할 병원: A (데이터가 많아서 신뢰도 높음)
```

**문제점**:
- 신규 병원이 우연히 1-2건 성공하면 100% 전환율
- 검증된 병원보다 높은 순위
- 운영 리스크 증가

---

### 해결: 베이지안 스무딩

#### 핵심 아이디어
> "적은 데이터는 전체 평균에 가깝게, 많은 데이터는 실제 성과에 가깝게"

#### 공식
```
Bayesian Score = (m * P + n * p) / (m + n)

m = Prior Strength (가중치, 기본값: 10)
P = Global Average (전체 병원 평균, 예: 0.3)
n = Sample Size (병원의 실제 데이터 수)
p = Hospital Rate (병원의 실제 전환율)
```

#### 예시 계산

**전제**:
- Global Average (P) = 30%
- Prior Strength (m) = 10

**병원 A (검증됨)**:
- 실제: 100건 중 40건 = 40%
- 계산: (10 * 0.3 + 100 * 0.4) / (10 + 100)
- 계산: (3 + 40) / 110 = 43 / 110 = 0.39
- **점수: 39%** (실제에 가까움)

**병원 B (신규)**:
- 실제: 2건 중 2건 = 100%
- 계산: (10 * 0.3 + 2 * 1.0) / (10 + 2)
- 계산: (3 + 2) / 12 = 5 / 12 = 0.42
- **점수: 42%** (전체 평균에 가까움)

**결과**:
```
단순 전환율:  B(100%) > A(40%)   ← 잘못된 순위
베이지안 점수: A(39%) < B(42%)   ← 거의 비슷 (더 안전)
```

하지만 신뢰도를 고려하면:
```
A: 신뢰도 = 100 / (10 + 100) = 91%
B: 신뢰도 = 2 / (10 + 2) = 17%

최종 추천: A (점수 비슷 + 신뢰도 높음)
```

---

### Prior Strength (m) 값 선택

| m 값 | 의미 | 효과 |
|------|------|------|
| 5 | 약한 보정 | 실제 데이터에 빠르게 반응 |
| 10 | 중간 보정 (기본값) | 균형 잡힌 접근 |
| 20 | 강한 보정 | 많은 데이터 필요 (보수적) |

**기본값 10 선택 이유**:
- 약 10건의 데이터부터 의미 있는 차이 발생
- 너무 보수적이지 않으면서 신규 병원 보호
- 대부분의 추천 시스템에서 사용하는 값

---

## 📈 신뢰도 (Confidence Level)

### 공식
```
Confidence = n / (m + n)

n = 실제 데이터 수
m = Prior Strength
```

### 해석
```
0-20%:   ⚠️ 데이터 매우 부족 (신중히)
20-50%:  📊 데이터 부족 (참고만)
50-80%:  ⭐ 데이터 충분 (신뢰 가능)
80-100%: 🔥 데이터 풍부 (강력 추천)
```

### 예시
```
병원 A: 5건 → 5/(10+5) = 33% (낮음)
병원 B: 20건 → 20/(10+20) = 67% (중간)
병원 C: 100건 → 100/(10+100) = 91% (높음)
```

---

## 🗄️ DB 구조

### 1. hospital_lead_assignments
**용도**: 어떤 리드를 어떤 병원에 전달했는지 기록

```sql
CREATE TABLE hospital_lead_assignments (
  inquiry_id INTEGER,      -- 문의 ID
  hospital_id INTEGER,     -- 병원 ID
  treatment_id INTEGER,    -- 시술 ID
  country TEXT,            -- 국가
  language TEXT,           -- 언어
  decision JSONB,          -- 결정 근거
  assigned_at TIMESTAMPTZ, -- 전달 시각
  assigned_by TEXT         -- manual/auto/recommendation_engine
);
```

**예시 데이터**:
```json
{
  "inquiry_id": 123,
  "hospital_id": 1,
  "treatment_id": 5,
  "country": "KR",
  "language": "ko",
  "decision": {
    "reason": "high_bayesian_score",
    "score": 0.85,
    "rank": 1,
    "alternatives": [
      {"hospital_id": 2, "score": 0.78, "rank": 2},
      {"hospital_id": 3, "score": 0.72, "rank": 3}
    ]
  }
}
```

---

### 2. hospital_performance_stats
**용도**: 집계된 성과 통계 (베이지안 점수 포함)

```sql
CREATE TABLE hospital_performance_stats (
  hospital_id INTEGER,
  treatment_id INTEGER,    -- NULL = 전체 시술
  country TEXT,            -- NULL = 전체 국가
  language TEXT,           -- NULL = 전체 언어
  period TEXT,             -- all_time, last_30d, last_7d
  
  -- 퍼널 카운트
  leads_sent INTEGER,
  leads_interested INTEGER,
  leads_booked INTEGER,
  leads_completed INTEGER,
  
  -- 전환율
  booking_rate NUMERIC,
  completion_rate NUMERIC,
  
  -- 베이지안 점수
  bayesian_score NUMERIC,  -- 0.0 ~ 1.0
  confidence_level NUMERIC, -- 0.0 ~ 1.0
  sample_size INTEGER
);
```

**차원 조합 예시**:
```
(hospital_id=1, treatment=NULL, country=NULL, language=NULL, period=last_30d)
→ 병원 1의 전체 성과 (최근 30일)

(hospital_id=1, treatment=5, country='KR', language='ko', period=last_30d)
→ 병원 1의 코성형(5) 한국인 한국어 성과 (최근 30일)
```

---

### 3. hospital_performance_global_avg
**용도**: 글로벌 평균 저장 (베이지안 계산용)

```sql
CREATE TABLE hospital_performance_global_avg (
  global_interest_rate NUMERIC DEFAULT 0.5,
  global_booking_rate NUMERIC DEFAULT 0.3,
  global_completion_rate NUMERIC DEFAULT 0.25,
  bayesian_m INTEGER DEFAULT 10
);
```

---

## 🔄 집계 프로세스

### 1. 수동 실행
```bash
# 전체 재계산
npx tsx scripts/hospital-performance-aggregator.ts refresh

# 결과:
# ✅ Successfully refreshed 45 rows in hospital_performance_stats
```

### 2. Cron 자동 실행 (권장)
```bash
# crontab -e
0 2 * * * cd /path/to/healo && npx tsx scripts/hospital-performance-aggregator.ts refresh
```
→ 매일 새벽 2시 자동 집계

### 3. SQL 함수 직접 호출
```sql
SELECT refresh_hospital_performance_stats();
```

---

## 🎯 추천 사용법

### 1. VIEW를 통한 추천 조회

```sql
-- 코성형(1) 한국(KR) 한국어(ko) 추천 병원 Top 5
SELECT 
  hospital_name,
  bayesian_score,
  confidence_level,
  breakdown
FROM v_hospital_recommendations
WHERE treatment_id = 1
  AND country = 'KR'
  AND language = 'ko'
ORDER BY bayesian_score DESC
LIMIT 5;
```

**결과 예시**:
```
hospital_name        | bayesian_score | confidence_level | breakdown
---------------------|----------------|------------------|----------
Seoul Plastic A      | 0.85           | 0.91             | {...}
Gangnam Beauty       | 0.78           | 0.87             | {...}
Korea Medical Center | 0.72           | 0.75             | {...}
New Clinic           | 0.45           | 0.20             | {...}
```

---

### 2. CLI 도구 사용

```bash
# 추천 조회
npx tsx scripts/hospital-performance-aggregator.ts recommend \
  --treatment 1 \
  --country KR \
  --language ko \
  --limit 5

# 결과:
# 🎯 병원 추천 조회
# 
# 1. Seoul Plastic Surgery A
#    점수: 85.0/100 (신뢰도: 91%)
#    데이터: 100건
#    예약율: 42.0%
#    완료율: 38.0%
#    응답 속도: 12.5시간
#    추천 등급: 🔥 강력 추천
```

---

### 3. 추천 등급 해석

| 등급 | 조건 | 의미 |
|------|------|------|
| 🔥 강력 추천 | 점수 70%+ & 데이터 10건+ | 검증됨, 높은 성과 |
| ⭐ 추천 | 점수 50%+ & 데이터 5건+ | 신뢰 가능 |
| 📊 고려 가능 | 점수 30%+ 또는 데이터 3건+ | 참고만 |
| 📉 데이터 부족 | 그 외 | 신중히 판단 |

---

## 💡 운영 시나리오

### 시나리오 1: 새 리드 전달 시

**입력**:
- 리드 #456 (코성형, 한국, 한국어)

**프로세스**:
```sql
-- 1. 추천 조회
SELECT * FROM v_hospital_recommendations
WHERE treatment_id = 1 AND country = 'KR' AND language = 'ko'
ORDER BY bayesian_score DESC LIMIT 3;

-- 결과:
-- 1. Seoul Plastic A (85점, 신뢰도 91%)
-- 2. Gangnam Beauty (78점, 신뢰도 87%)
-- 3. Korea Medical (72점, 신뢰도 75%)
```

**운영자 판단**:
- ✅ Seoul Plastic A 선택 (최고 점수 + 높은 신뢰도)
- 📝 decision JSON 기록:
```json
{
  "reason": "highest_bayesian_score",
  "score": 0.85,
  "rank": 1,
  "alternatives": [
    {"hospital_id": 2, "score": 0.78},
    {"hospital_id": 3, "score": 0.72}
  ]
}
```

**기록**:
```sql
INSERT INTO hospital_lead_assignments (
  inquiry_id, hospital_id, treatment_id, 
  country, language, decision, assigned_by
) VALUES (
  456, 1, 1, 
  'KR', 'ko', '{"reason": "highest_bayesian_score", ...}', 'manual'
);
```

---

### 시나리오 2: 신규 병원 추가

**상황**:
- New Hospital 추가됨
- 데이터 0건

**초기 점수**:
```
베이지안 점수 = (10 * 0.3 + 0 * 0) / (10 + 0) = 0.3 (30%)
신뢰도 = 0 / (10 + 0) = 0%
```

**추천 등급**: 📉 데이터 부족

**전략**:
1. 일부 리드 시범 전달 (2-3건)
2. 결과 확인
3. 성과 좋으면 점진적 증가

---

### 시나리오 3: 성과 하락 병원

**상황**:
- 기존 A급 병원 (점수 85%)
- 최근 30일 성과 하락 (점수 55%)

**데이터**:
```sql
-- all_time: 85점 (100건 기반)
-- last_30d: 55점 (10건 기반)
```

**운영 조치**:
1. last_30d 기준으로 추천 순위 하락 (자동)
2. 병원에 피드백 (수동)
3. 원인 파악 (담당자 변경? 정책 변경?)
4. 개선 안 되면 리드 전달 축소

---

## 📊 성과 모니터링

### 1. 전체 병원 대시보드

```bash
npx tsx scripts/hospital-performance-aggregator.ts dashboard
```

**결과**:
```
┌─────────────────────────┬──────┬───────────┬──────────┬──────┬─────────────┐
│ 병원                    │ 점수 │ 신뢰도(%) │ 리드 수  │ 예약 │ 예약율(%)   │
├─────────────────────────┼──────┼───────────┼──────────┼──────┼─────────────┤
│ Seoul Plastic A         │ 85.0 │ 91        │ 100      │ 42   │ 42.0        │
│ Gangnam Beauty          │ 78.0 │ 87        │ 80       │ 32   │ 40.0        │
│ Korea Medical Center    │ 72.0 │ 75        │ 50       │ 18   │ 36.0        │
│ New Clinic              │ 45.0 │ 20        │ 3        │ 1    │ 33.3        │
└─────────────────────────┴──────┴───────────┴──────────┴──────┴─────────────┘
```

---

### 2. 특정 병원 상세

```bash
npx tsx scripts/hospital-performance-aggregator.ts show-hospital 1
```

**결과**:
```
📊 병원 #1 성과 조회

병원명: Seoul Plastic Surgery A

=== 최근 30일 성과 ===
전달된 리드: 100건
관심 표명: 70건
예약 확정: 42건
시술 완료: 38건

=== 전환율 ===
관심률: 70.0%
예약율: 42.0%
완료율: 38.0%

=== 속도 ===
평균 응답 시간: 12.5시간

=== 베이지안 점수 ===
점수: 85.0/100
신뢰도: 91.0%
샘플 크기: 100건

성과 등급: 🔥 Excellent
```

---

## 🔬 베이지안 시뮬레이션

```bash
npx tsx scripts/hospital-performance-aggregator.ts simulate
```

**결과**:
```
🧪 베이지안 스무딩 시뮬레이션

글로벌 평균: 30.0%
Prior Strength (m): 10

신생 병원 (2/2 = 100%)
  실제 전환율: 100.0%
  베이지안 점수: 41.7%
  신뢰도: 16.7%

중견 병원 (8/10 = 80%)
  실제 전환율: 80.0%
  베이지안 점수: 55.0%
  신뢰도: 50.0%

대형 병원 (40/100 = 40%)
  실제 전환율: 40.0%
  베이지안 점수: 39.1%
  신뢰도: 90.9%

부진 병원 (1/20 = 5%)
  실제 전환율: 5.0%
  베이지안 점수: 13.3%
  신뢰도: 66.7%

💡 해석:
- 신생 병원: 100%지만 데이터 부족 → 점수 낮음 (전체 평균에 가까움)
- 대형 병원: 실제 40%에 가까운 점수 (데이터 많아서 신뢰도 높음)
```

---

## 🎓 고급 기능

### 1. 차원별 성과

병원은 다양한 차원에서 성과가 다를 수 있음:

```sql
-- 병원 1의 코성형 성과
SELECT * FROM hospital_performance_stats
WHERE hospital_id = 1 AND treatment_id = 1;

-- 병원 1의 한국인 대상 성과
SELECT * FROM hospital_performance_stats
WHERE hospital_id = 1 AND country = 'KR';

-- 병원 1의 전체 성과
SELECT * FROM hospital_performance_stats
WHERE hospital_id = 1 
  AND treatment_id IS NULL 
  AND country IS NULL 
  AND language IS NULL;
```

**활용**:
- 병원마다 강점 시술/국가가 다름
- 세분화된 추천 가능

---

### 2. 기간별 트렌드

```sql
-- 전체 vs 최근 30일 비교
SELECT 
  period,
  bayesian_score,
  sample_size
FROM hospital_performance_stats
WHERE hospital_id = 1
  AND treatment_id IS NULL
  AND period IN ('all_time', 'last_30d');
```

**해석**:
- last_30d > all_time: 🔥 성과 상승
- last_30d < all_time: ⚠️ 성과 하락
- 차이 크면 조사 필요

---

### 3. 속도 지표

```sql
SELECT 
  hospital_name,
  avg_first_response_minutes / 60 as avg_response_hours,
  bayesian_score
FROM v_hospital_recommendations
WHERE treatment_id = 1
ORDER BY avg_first_response_minutes ASC;
```

**활용**:
- 점수 비슷하면 빠른 병원 우선
- 긴급 리드는 속도 중시

---

## ⚠️ 주의사항

### 1. 데이터 품질
- ❌ hospital_responses 상태가 정확하지 않으면 → 잘못된 학습
- ✅ 정기적으로 데이터 검증 필요

### 2. Cold Start 극복
- 신규 병원은 초기에 낮은 점수 (의도된 동작)
- 소량 시범 전달 후 평가
- 급격한 증가보다 점진적 증가

### 3. 집계 주기
- 실시간 아님 (배치 집계)
- 매일 새벽 자동 갱신 권장
- 긴급 시 수동 실행: `refresh`

### 4. 다차원 데이터
- 차원이 많을수록 데이터 희소
- 너무 세분화하지 말 것
- 전체 → 시술별 → 국가별 순으로 확장

---

## 📈 기대 효과

### Before (수동 판단)
```
운영자 감으로 병원 선택
↓
일부 병원 편중
↓
신규 병원 시도 어려움
↓
최적화 불가능
```

### After (데이터 기반)
```
베이지안 점수 기반 추천
↓
성과 좋은 병원에 자연스럽게 집중
↓
신규 병원도 공정하게 평가
↓
지속적 최적화
```

### 예상 개선
- 📊 평균 전환율: 30% → 35-40% (10-30% 향상)
- ⏱️ 병원 선정 시간: 10분 → 1분 (90% 절감)
- 🎯 신규 병원 발굴: 어려움 → 자동 (공정한 기회)

---

## 🔧 문제 해결

### Q1. 점수가 모두 비슷해요
**A**: 
- 정상입니다 (데이터 부족 초기)
- 데이터 쌓이면 차이 발생
- 강제로 차이 만들지 말 것

### Q2. 신규 병원 점수가 너무 낮아요
**A**:
- 의도된 동작 (Cold Start 보호)
- m 값을 낮추면 빠르게 반영 (위험 증가)
- 소량 시범 전달 권장

### Q3. 점수가 갑자기 떨어졌어요
**A**:
```sql
-- 최근 데이터 확인
SELECT * FROM hospital_responses
WHERE hospital_name = '...'
  AND sent_at > NOW() - INTERVAL '7 days';
```
- 실제 성과 하락 가능성
- 데이터 오류 가능성
- 원인 파악 후 조치

### Q4. 집계가 안 돼요
**A**:
```sql
-- 함수 존재 확인
SELECT * FROM pg_proc WHERE proname = 'refresh_hospital_performance_stats';

-- 수동 실행 테스트
SELECT refresh_hospital_performance_stats();
```

---

## 📚 참고 자료

### 베이지안 추정 (Bayesian Estimation)
- [Wikipedia: Bayesian Average](https://en.wikipedia.org/wiki/Bayesian_average)
- IMDB, Yelp 등에서 사용하는 방식

### 추천 시스템
- Cold Start Problem
- Prior Belief
- Posterior Estimation

### 관련 문서
- `P3_HOSPITAL_LEAD_SUMMARY.md` - 리드 전달 기본
- `OPERATIONAL_DASHBOARD_GUIDE.md` - 대시보드 가이드

---

## 🚀 시작하기

### 1. DB 마이그레이션
```bash
# Supabase SQL Editor에서 실행
migrations/20260129_add_hospital_performance.sql
```

### 2. 초기 집계
```bash
npx tsx scripts/hospital-performance-aggregator.ts refresh
```

### 3. 추천 조회 테스트
```bash
npx tsx scripts/hospital-performance-aggregator.ts recommend --treatment 1 --country KR
```

### 4. Cron 설정 (선택)
```bash
crontab -e
# 추가:
0 2 * * * cd /path/to/healo && npx tsx scripts/hospital-performance-aggregator.ts refresh
```

---

**이제 데이터가 쌓이면서 자동으로 학습합니다!** 🎓
