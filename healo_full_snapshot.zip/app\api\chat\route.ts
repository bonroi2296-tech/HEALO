import { streamText } from "ai";
import { openai } from "@ai-sdk/openai";
import { supabaseAdmin } from "../../../src/lib/rag/supabaseAdmin";

type ChatMessage = { role: string; content: string };

const buildContext = (chunks: Array<any>) => {
  if (!Array.isArray(chunks) || chunks.length === 0) return "";
  const lines = chunks.map((c) => {
    const title = c?.rag_documents?.title ? ` | ${c.rag_documents.title}` : "";
    const source = c?.rag_documents?.source_type
      ? `[${c.rag_documents.source_type}${title}]`
      : "[source]";
    return `${source} ${String(c.content || "").trim()}`;
  });
  return lines.join("\n\n");
};

const getLastUserMessage = (messages: ChatMessage[] = []) => {
  for (let i = messages.length - 1; i >= 0; i -= 1) {
    if (messages[i]?.role === "user") return messages[i];
  }
  return null;
};

export async function POST(request: Request) {
  if (!process.env.OPENAI_API_KEY) {
    return Response.json(
      { ok: false, error: "OPENAI_API_KEY is missing" },
      { status: 500 }
    );
  }

  const body = await request.json().catch(() => ({}));
  const messages: ChatMessage[] = Array.isArray(body?.messages)
    ? body.messages
    : [];
  const lang = body?.lang ? String(body.lang) : "en";
  const sessionId = body?.session_id ? String(body.session_id) : null;
  const page = body?.page ? String(body.page) : null;
  const utm = body?.utm && typeof body.utm === "object" ? body.utm : null;
  const lastUser = getLastUserMessage(messages);
  const query = String(lastUser?.content || "").trim();

  if (!query) {
    return Response.json(
      { ok: false, error: "user_message_required" },
      { status: 400 }
    );
  }

  // Log normalized inquiry (best effort).
  void (async () => {
    try {
      await supabaseAdmin.from("normalized_inquiries").insert({
        source_type: "ai_agent",
        language: lang,
        raw_message: query,
        constraints: {
          session_id: sessionId,
          page,
          utm,
        },
        treatment_slug: null,
        objective: null,
      });
    } catch {}
  })();

  // RAG retrieval (top 6).
  let ragChunks: any[] = [];
  try {
    let q = supabaseAdmin
      .from("rag_chunks")
      .select(
        "id, document_id, chunk_index, content, rag_documents(id, source_type, source_id, lang, title)"
      )
      .ilike("content", `%${query}%`)
      .limit(6);
    if (lang) q = q.eq("rag_documents.lang", lang);
    const { data, error } = await q;
    if (!error) ragChunks = data || [];
  } catch {}

  const context = buildContext(ragChunks);

  const systemPrompt = [
    "You are a medical concierge assistant for HEALO.",
    "Do not provide diagnosis, medical advice, or guarantees.",
    "Ask clarifying questions when constraints are missing.",
    "Primary objective: guide the user to submit an inquiry.",
    "If relevant, reference the provided context briefly.",
    "",
    context ? "Context:\n" + context : "",
  ]
    .filter(Boolean)
    .join("\n");

  try {
    const result = await streamText({
      model: openai("gpt-4o-mini"),
      system: systemPrompt,
      messages: messages as any,
      onError: ({ error }) => {
        console.error("[api/chat] stream error:", error);
      },
    });
    return result.toDataStreamResponse();
  } catch (error: any) {
    console.error("[api/chat] LLM error:", error);
    return Response.json(
      { ok: false, error: "llm_failed", detail: error?.message || "unknown" },
      { status: 500 }
    );
  }
}
