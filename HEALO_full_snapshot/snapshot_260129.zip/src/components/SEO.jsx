// src/components/SEO.jsx
import React from "react";

export const SEO = () => null;
export default SEO;