import { supabaseAdmin } from "../../../../src/lib/rag/supabaseAdmin";

const detectLanguage = (value: string | null | undefined) => {
  const v = String(value || "").toLowerCase();
  if (v.includes("ko") || v.includes("kr") || v.includes("korean")) return "ko";
  if (v.includes("ja") || v.includes("jp") || v.includes("japanese")) return "ja";
  return "en";
};

export async function POST(request: Request) {
  try {
    const body = await request.json().catch(() => ({}));
    const text = body?.text ? String(body.text) : "";
    const inquiryId = body?.inquiry_id ? Number(body.inquiry_id) : null;

    if (!text && !inquiryId) {
      return Response.json(
        { ok: false, error: "text_or_inquiry_id_required" },
        { status: 400 }
      );
    }

    let inquiryRow: any = null;
    if (inquiryId) {
      const { data, error } = await supabaseAdmin
        .from("inquiries")
        .select(
          "id, first_name, last_name, email, nationality, spoken_language, contact_method, contact_id, treatment_type, message"
        )
        .eq("id", inquiryId)
        .single();
      if (error) throw error;
      inquiryRow = data;
    }

    const rawMessage = text || inquiryRow?.message || null;
    const language = detectLanguage(inquiryRow?.spoken_language);

    const { data: inserted, error: insertError } = await supabaseAdmin
      .from("normalized_inquiries")
      .insert({
        source_type: inquiryRow ? "inquiry_form" : "ai_agent",
        source_inquiry_id: inquiryRow ? inquiryRow.id : null,
        language,
        country: inquiryRow?.nationality || null,
        treatment_slug: inquiryRow?.treatment_type || null,
        objective: null,
        constraints: {},
        raw_message: rawMessage,
        extraction_confidence: null,
        missing_fields: null,
        contact: inquiryRow
          ? {
              email: inquiryRow.email || null,
              messenger_channel: inquiryRow.contact_method || null,
              messenger_handle: inquiryRow.contact_id || null,
            }
          : null,
      })
      .select("*")
      .single();

    if (insertError) throw insertError;

    return Response.json({ ok: true, normalized: inserted });
  } catch (error: any) {
    return Response.json(
      { ok: false, error: error?.message || "normalize_failed" },
      { status: 500 }
    );
  }
}
