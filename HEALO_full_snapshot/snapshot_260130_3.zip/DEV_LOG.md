## 2026-01-23

### ✨ Refactoring (리팩토링)
- AdminPage를 탭별 컴포넌트로 분리했습니다.
- AnalyticsTab, InquiryManager, HospitalManager, TreatmentManager, SiteSettings로 분리했습니다.
- AdminPage는 탭 컨테이너 역할만 하도록 정리했습니다.

### 🐛 Bug Fix (버그 수정)
- HospitalManager에서 AddressInput 반환 키 매핑을 koAddress/enAddress로 수정했습니다.

### 🔨 Feature (기능)
- 해당 없음.
