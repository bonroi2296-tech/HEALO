import HomeClient from "./home/HomeClient";

export default function HomePage() {
  return <HomeClient />;
}
