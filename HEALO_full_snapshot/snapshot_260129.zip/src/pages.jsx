export { TreatmentDetailPage } from './legacy-pages/TreatmentDetailPage';
export { HospitalDetailPage } from './legacy-pages/HospitalDetailPage';
export { InquiryPage } from './legacy-pages/InquiryPage';
export { InquiryIntakePage } from './legacy-pages/InquiryIntakePage';
export { SuccessPage, LoginPage, SignUpPage } from './legacy-pages/AuthPages';
