# HEALO Admin Audit DB 검증 체크리스트

**작성일**: 2026-01-30  
**목적**: `admin_audit_logs.inquiry_ids`를 INT4[]로 변경 후 UUID 관련 잔재 확인

---

## 📋 작업 맥락 요약

### 오늘 수행한 주요 작업

**Phase 2 보안 강화 완료 후 발생한 이슈들을 해결:**

1. **Next.js 15 Params Promise 이슈 수정**
   - `/api/admin/inquiries/[id]`에서 `params is a Promise` 에러 발생
   - Next.js 15부터 route handler params가 Promise로 변경됨
   - 해결: `context: { params: Promise<{ id: string }> }` + `await context.params`

2. **Audit Log UUID 타입 에러 수정**
   - 서버 로그: `invalid input syntax for type uuid: "15"`
   - 원인: `admin_audit_logs.inquiry_ids`가 UUID[]로 설계되었으나, `inquiries.id`는 integer
   - 해결:
     - Migration: `inquiry_ids UUID[]` → `INT4[]`
     - TypeScript: `inquiryIds: string[]` → `number[]`
     - 안전한 `toIntArray()` 헬퍼 함수 추가
     - 모든 호출부 수정 (number[] 전달)

3. **이메일 검증 강화**
   - `includes('@')` → 정규식 `/^[^\s@]+@[^\s@]+\.[^\s@]+$/`
   - API 레벨 + 클라이언트 레벨 동시 적용

4. **Normalize API 수정**
   - RAG 시스템을 위해 필수
   - DB 함수(`encrypt_text`) → Node.js crypto 직접 사용
   - `encryptionV2.ts`로 통일

**현재 상태**: 모든 기능 정상 작동, 하지만 DB 내부에 UUID 캐스팅 잔재가 남아있을 수 있음

---

## 🔍 DB 검증 SQL 세트

아래 SQL들을 **Supabase SQL Editor**에서 순서대로 실행하세요.  
**모든 결과가 0 rows이면 "UUID 잔재 없음"으로 판정됩니다.**

---

### 1️⃣ admin_audit_logs.inquiry_ids 컬럼 타입 확인

**목적**: 타입이 INT4[]로 올바르게 변경되었는지 확인

```sql
-- admin_audit_logs.inquiry_ids 컬럼 타입 확인
SELECT 
    table_schema,
    table_name,
    column_name,
    data_type,
    udt_name,
    CASE 
        WHEN udt_name = '_int4' THEN '✅ 올바름 (INT4[])'
        WHEN udt_name = '_uuid' THEN '❌ 아직 UUID[]'
        ELSE '⚠️ 예상치 못한 타입: ' || udt_name
    END AS status
FROM information_schema.columns
WHERE table_schema = 'public'
  AND table_name = 'admin_audit_logs'
  AND column_name = 'inquiry_ids';

-- 예상 결과:
-- | column_name  | data_type | udt_name | status            |
-- |--------------|-----------|----------|-------------------|
-- | inquiry_ids  | ARRAY     | _int4    | ✅ 올바름 (INT4[]) |
--
-- ❌ 만약 udt_name이 '_uuid'이면 마이그레이션 미실행
```

---

### 2️⃣ 함수 정의에서 UUID 관련 문자열 찾기

**목적**: public 스키마 함수에서 'uuid', '::uuid', 'uuid[]' 사용 여부 확인

```sql
-- public 스키마의 함수 정의에서 UUID 관련 문자열 검색
SELECT 
    n.nspname AS schema_name,
    p.proname AS function_name,
    pg_get_functiondef(p.oid) AS function_definition,
    CASE
        WHEN pg_get_functiondef(p.oid) ILIKE '%inquiry_ids%uuid%' THEN '❌ inquiry_ids에 UUID 사용'
        WHEN pg_get_functiondef(p.oid) ILIKE '%::uuid%' THEN '⚠️ UUID 캐스팅 사용'
        WHEN pg_get_functiondef(p.oid) ILIKE '%uuid[]%' THEN '⚠️ UUID 배열 타입 사용'
        ELSE '⚠️ 기타 UUID 관련 사용'
    END AS issue_type
FROM pg_proc p
JOIN pg_namespace n ON p.pronamespace = n.oid
WHERE n.nspname = 'public'
  AND (
    pg_get_functiondef(p.oid) ILIKE '%uuid%'
    OR pg_get_functiondef(p.oid) ILIKE '%::uuid%'
  );

-- 예상 결과: 0 rows (UUID 관련 함수 없음)
--
-- ❌ 만약 결과가 있으면:
--    - inquiry_ids 관련 함수가 있는지 확인
--    - 있다면 해당 함수 수정 필요 (INT4[]로 변경)
```

---

### 3️⃣ 트리거 정의에서 UUID 관련 문자열 찾기

**목적**: admin_audit_logs 관련 트리거에서 UUID 캐스팅 사용 여부 확인

```sql
-- 트리거 정의에서 UUID 관련 문자열 검색
SELECT 
    tgname AS trigger_name,
    tgrelid::regclass AS table_name,
    pg_get_triggerdef(oid) AS trigger_definition,
    CASE
        WHEN pg_get_triggerdef(oid) ILIKE '%inquiry_ids%uuid%' THEN '❌ inquiry_ids에 UUID 사용'
        WHEN pg_get_triggerdef(oid) ILIKE '%::uuid%' THEN '⚠️ UUID 캐스팅 사용'
        ELSE '⚠️ 기타 UUID 관련 사용'
    END AS issue_type
FROM pg_trigger
WHERE tgrelid = 'public.admin_audit_logs'::regclass
  AND NOT tgisinternal  -- 내부 트리거 제외
  AND (
    pg_get_triggerdef(oid) ILIKE '%uuid%'
    OR pg_get_triggerdef(oid) ILIKE '%::uuid%'
  );

-- 예상 결과: 0 rows (UUID 관련 트리거 없음)
--
-- ❌ 만약 결과가 있으면:
--    - 트리거에서 inquiry_ids를 UUID로 캐스팅하는지 확인
--    - 있다면 트리거 수정 또는 삭제 필요
```

---

### 4️⃣ RLS 정책에서 UUID 관련 문자열 찾기

**목적**: admin_audit_logs의 RLS 정책에서 UUID 사용 여부 확인

```sql
-- RLS 정책 정의에서 UUID 관련 문자열 검색
SELECT 
    schemaname,
    tablename,
    policyname,
    definition,
    CASE
        WHEN definition ILIKE '%inquiry_ids%uuid%' THEN '❌ inquiry_ids에 UUID 사용'
        WHEN definition ILIKE '%::uuid%' THEN '⚠️ UUID 캐스팅 사용'
        WHEN definition ILIKE '%uuid[]%' THEN '⚠️ UUID 배열 사용'
        ELSE '⚠️ 기타 UUID 관련 사용'
    END AS issue_type
FROM pg_policies
WHERE schemaname = 'public'
  AND tablename = 'admin_audit_logs'
  AND (
    definition ILIKE '%uuid%'
    OR definition ILIKE '%::uuid%'
  );

-- 예상 결과: 0 rows (UUID 관련 정책 없음)
--
-- 참고: 현재 정책은 auth.email() 기반이므로 inquiry_ids 사용 안 함
--
-- ❌ 만약 결과가 있으면:
--    - 정책이 inquiry_ids를 UUID로 비교하는지 확인
--    - 있다면 정책 재생성 필요
```

---

### 5️⃣ 뷰 정의에서 UUID 관련 문자열 찾기

**목적**: admin_audit_logs를 참조하는 뷰에서 UUID 캐스팅 사용 여부 확인

```sql
-- 뷰 정의에서 UUID 관련 문자열 검색 (admin_audit_logs 참조)
SELECT 
    schemaname,
    viewname,
    definition,
    CASE
        WHEN definition ILIKE '%inquiry_ids%uuid%' THEN '❌ inquiry_ids에 UUID 사용'
        WHEN definition ILIKE '%::uuid%' THEN '⚠️ UUID 캐스팅 사용'
        WHEN definition ILIKE '%uuid[]%' THEN '⚠️ UUID 배열 사용'
        ELSE '⚠️ 기타 UUID 관련 사용'
    END AS issue_type
FROM pg_views
WHERE schemaname = 'public'
  AND definition ILIKE '%admin_audit_logs%'
  AND (
    definition ILIKE '%uuid%'
    OR definition ILIKE '%::uuid%'
  );

-- 예상 결과: 0 rows (UUID 관련 뷰 없음)
--
-- 참고: 현재 admin_audit_logs를 참조하는 뷰는 없을 가능성이 높음
--
-- ❌ 만약 결과가 있으면:
--    - 뷰가 inquiry_ids를 UUID로 캐스팅하는지 확인
--    - 있다면 뷰 재생성 필요
```

---

### 6️⃣ inquiries 테이블의 id 컬럼 타입 확인

**목적**: inquiries.id가 integer(INT4)인지 재확인

```sql
-- inquiries.id 컬럼 타입 확인
SELECT 
    table_schema,
    table_name,
    column_name,
    data_type,
    udt_name,
    CASE 
        WHEN udt_name = 'int4' THEN '✅ 올바름 (integer/INT4)'
        WHEN udt_name = 'uuid' THEN '❌ UUID (예상과 다름)'
        ELSE '⚠️ 예상치 못한 타입: ' || udt_name
    END AS status
FROM information_schema.columns
WHERE table_schema = 'public'
  AND table_name = 'inquiries'
  AND column_name = 'id';

-- 예상 결과:
-- | column_name | data_type | udt_name | status                    |
-- |-------------|-----------|----------|---------------------------|
-- | id          | integer   | int4     | ✅ 올바름 (integer/INT4)   |
--
-- 참고: inquiries.id는 serial (자동 증가 integer)
```

---

### 7️⃣ 최근 audit log 데이터 샘플 확인

**목적**: 실제 데이터가 integer array로 저장되는지 확인

```sql
-- 최근 audit log 5건 확인
SELECT 
    id,
    action,
    inquiry_ids,
    pg_typeof(inquiry_ids) AS inquiry_ids_type,
    admin_email,
    created_at,
    CASE
        WHEN pg_typeof(inquiry_ids)::text = 'integer[]' THEN '✅ 올바른 타입'
        WHEN pg_typeof(inquiry_ids)::text = 'uuid[]' THEN '❌ 여전히 UUID[]'
        WHEN inquiry_ids IS NULL THEN '⚠️ NULL'
        ELSE '⚠️ 예상치 못한 타입'
    END AS status
FROM public.admin_audit_logs
ORDER BY created_at DESC
LIMIT 5;

-- 예상 결과:
-- | action         | inquiry_ids | inquiry_ids_type | status          |
-- |----------------|-------------|------------------|-----------------|
-- | VIEW_INQUIRY   | {15}        | integer[]        | ✅ 올바른 타입   |
-- | LIST_INQUIRIES | {13,14,15}  | integer[]        | ✅ 올바른 타입   |
--
-- ❌ 만약 inquiry_ids_type이 uuid[]이면:
--    - 마이그레이션이 제대로 실행되지 않았거나
--    - 이전 데이터가 남아있음
--    - 해결: 테이블 재생성 또는 데이터 삭제 후 재삽입
```

---

## 📊 검증 결과 해석

### ✅ 모든 체크 통과 기준

1. **1️⃣**: `udt_name = '_int4'` ✅
2. **2️⃣**: 0 rows (함수에 UUID 없음) ✅
3. **3️⃣**: 0 rows (트리거에 UUID 없음) ✅
4. **4️⃣**: 0 rows (정책에 UUID 없음) ✅
5. **5️⃣**: 0 rows (뷰에 UUID 없음) ✅
6. **6️⃣**: `udt_name = 'int4'` ✅
7. **7️⃣**: `pg_typeof = 'integer[]'` ✅

### ❌ 문제 발견 시 조치

| 체크 | 문제 | 조치 |
|------|------|------|
| 1️⃣ | `udt_name = '_uuid'` | `migrations/20260130_fix_audit_inquiry_ids_type.sql` 실행 |
| 2️⃣ | 함수에 UUID 사용 | 함수 재생성 (INT4[]로 변경) |
| 3️⃣ | 트리거에 UUID 사용 | 트리거 수정 또는 삭제 |
| 4️⃣ | 정책에 UUID 사용 | 정책 재생성 |
| 5️⃣ | 뷰에 UUID 사용 | 뷰 재생성 |
| 7️⃣ | 데이터가 uuid[] | 기존 데이터 삭제 또는 변환 |

---

## 🔧 추가 유틸리티 쿼리

### UUID 관련 전체 검색 (디버깅용)

```sql
-- public 스키마의 모든 객체에서 'inquiry_ids' + 'uuid' 조합 검색
-- (함수, 트리거, 뷰, 정책 모두 포함)

-- 1. 함수
SELECT 'FUNCTION' AS object_type, proname AS object_name, pg_get_functiondef(oid) AS definition
FROM pg_proc
WHERE pronamespace = 'public'::regnamespace
  AND pg_get_functiondef(oid) ILIKE '%inquiry_ids%'
  AND pg_get_functiondef(oid) ILIKE '%uuid%'

UNION ALL

-- 2. 트리거
SELECT 'TRIGGER' AS object_type, tgname AS object_name, pg_get_triggerdef(oid) AS definition
FROM pg_trigger
WHERE tgrelid IN (SELECT oid FROM pg_class WHERE relnamespace = 'public'::regnamespace)
  AND pg_get_triggerdef(oid) ILIKE '%inquiry_ids%'
  AND pg_get_triggerdef(oid) ILIKE '%uuid%'

UNION ALL

-- 3. 뷰
SELECT 'VIEW' AS object_type, viewname AS object_name, definition
FROM pg_views
WHERE schemaname = 'public'
  AND definition ILIKE '%inquiry_ids%'
  AND definition ILIKE '%uuid%'

UNION ALL

-- 4. 정책
SELECT 'POLICY' AS object_type, policyname AS object_name, definition
FROM pg_policies
WHERE schemaname = 'public'
  AND definition ILIKE '%inquiry_ids%'
  AND definition ILIKE '%uuid%';

-- 예상 결과: 0 rows
--
-- 이 쿼리는 디버깅용이므로 정상 작동 시 실행할 필요 없음
```

---

## 📝 체크리스트 실행 로그

**실행자**: ___________  
**실행일**: ___________

| 체크 | 결과 | 비고 |
|------|------|------|
| 1️⃣ 컬럼 타입 | ⬜ PASS / ⬜ FAIL | udt_name: _______ |
| 2️⃣ 함수 | ⬜ PASS / ⬜ FAIL | rows: _______ |
| 3️⃣ 트리거 | ⬜ PASS / ⬜ FAIL | rows: _______ |
| 4️⃣ 정책 | ⬜ PASS / ⬜ FAIL | rows: _______ |
| 5️⃣ 뷰 | ⬜ PASS / ⬜ FAIL | rows: _______ |
| 6️⃣ inquiries.id | ⬜ PASS / ⬜ FAIL | udt_name: _______ |
| 7️⃣ 실제 데이터 | ⬜ PASS / ⬜ FAIL | pg_typeof: _______ |

**종합 결과**: ⬜ 모든 체크 통과 / ⬜ 조치 필요

---

## 🎯 다음 단계

### ✅ 모든 체크 통과 시
- 작업 완료
- 로컬 테스트 진행
- Vercel 배포

### ❌ 문제 발견 시
1. 위 "문제 발견 시 조치" 테이블 참고
2. 필요한 마이그레이션/수정 실행
3. 다시 체크리스트 실행
4. 모두 통과할 때까지 반복

---

**작성자**: Cursor AI  
**문서 버전**: 1.0  
**관련 파일**:
- `migrations/20260129_add_admin_audit_logs.sql`
- `migrations/20260130_fix_audit_inquiry_ids_type.sql`
- `src/lib/audit/adminAuditLog.ts`
- `app/api/admin/inquiries/[id]/route.ts`
- `app/api/admin/inquiries/route.ts`
