/**
 * HEALO: 관리자 권한 체크 유틸 (SSR-safe)
 * 
 * 목적:
 * - API route에서 관리자 권한 확인
 * - @supabase/ssr의 createServerClient 사용 (쿠키 기반)
 * - 복호화 권한 부여 전 사용
 * 
 * 권한 판정 기준 (OR 조건):
 * 1. user.user_metadata.role === "admin"
 * 2. user.app_metadata.role === "admin"
 * 3. 환경변수 ADMIN_EMAIL_ALLOWLIST에 포함된 이메일
 * 
 * 환경변수:
 * - ADMIN_EMAIL_ALLOWLIST: 쉼표로 구분된 관리자 이메일 목록
 *   예: "admin@healo.com,manager@healo.com"
 * 
 * 사용법:
 * ```ts
 * const authResult = await checkAdminAuth();
 * if (!authResult.isAdmin) {
 *   return Response.json({ ok: false, error: "unauthorized" }, { status: 403 });
 * }
 * ```
 */

import { createSupabaseServerClient } from "../supabase/server";

/**
 * ✅ 환경변수에서 관리자 이메일 화이트리스트 로드
 */
function getAdminEmailAllowlist(): string[] {
  const allowlistEnv = process.env.ADMIN_EMAIL_ALLOWLIST;
  
  if (!allowlistEnv) {
    return [];
  }

  // 쉼표로 구분, trim, 빈 문자열 제거, 소문자 변환
  return allowlistEnv
    .split(",")
    .map((email) => email.trim().toLowerCase())
    .filter((email) => email.length > 0);
}

/**
 * ✅ 관리자 권한 확인 (Bearer token 우선, 쿠키 fallback)
 * 
 * 우선순위:
 * 1. Authorization: Bearer <token> 헤더 → supabaseAdmin.auth.getUser(token)
 * 2. 없으면 쿠키 기반 세션 확인 → createSupabaseServerClient().auth.getUser()
 * 
 * 판정 기준 (OR 조건):
 * 1. user.user_metadata.role === "admin"
 * 2. user.app_metadata.role === "admin"
 * 3. ADMIN_EMAIL_ALLOWLIST에 포함된 이메일
 * 
 * @param request NextRequest (optional, for Bearer token)
 * @returns { isAdmin: boolean, userId?: string, email?: string, reason?: string, error?: string, debug?: object }
 */
export async function checkAdminAuth(request?: any): Promise<{
  isAdmin: boolean;
  userId?: string;
  email?: string;
  reason?: string;
  authMethod?: string;
  error?: string;
  debug?: any;
}> {
  const isDev = process.env.NODE_ENV !== "production";
  const debugInfo: any = {};

  try {
    let user: any = null;
    let userError: any = null;
    let authMethod = "unknown";

    // ========================================
    // 1. Authorization Bearer 토큰 우선 (클라이언트 → 서버)
    // ========================================
    if (request?.headers) {
      const authHeader = request.headers.get?.("authorization") || request.headers.get?.("Authorization");
      
      if (authHeader?.startsWith("Bearer ")) {
        const token = authHeader.substring(7);
        
        if (isDev) {
          debugInfo.hasBearerToken = true;
          debugInfo.tokenLength = token?.length || 0;
        }

        try {
          // supabaseAdmin으로 토큰 검증
          const { supabaseAdmin } = await import("../rag/supabaseAdmin");
          const { data, error } = await supabaseAdmin.auth.getUser(token);
          
          user = data?.user;
          userError = error;
          authMethod = "bearer_token";
          
          if (isDev) {
            debugInfo.bearerTokenValid = !!user;
            debugInfo.bearerTokenError = error?.message;
          }
        } catch (err: any) {
          console.error("[checkAdminAuth] Bearer token validation error:", err.message);
          userError = err;
        }
      }
    }

    // ========================================
    // 2. 쿠키 기반 fallback (서버 SSR)
    // ========================================
    if (!user) {
      try {
        const supabase = createSupabaseServerClient();
        const { data, error } = await supabase.auth.getUser();
        
        user = data?.user;
        userError = error;
        authMethod = "cookie";
        
        if (isDev) {
          debugInfo.cookieAuthAttempted = true;
          debugInfo.cookieAuthValid = !!user;
          debugInfo.cookieAuthError = error?.message;
        }
      } catch (err: any) {
        console.error("[checkAdminAuth] Cookie auth error:", err.message);
        userError = err;
      }
    }

    // ========================================
    // 3. 유저 확인
    // ========================================
    if (isDev) {
      debugInfo.hasUser = !!user;
      debugInfo.userError = userError?.message;
      debugInfo.authMethod = authMethod;
    }

    if (userError || !user) {
      if (isDev) {
        console.warn('[checkAdminAuth] No user:', userError?.message || 'no session', 'method:', authMethod);
      }
      return {
        isAdmin: false,
        authMethod,
        error: userError?.message || "no_user",
        debug: isDev ? debugInfo : undefined,
      };
    }

    const userEmail = user.email?.trim().toLowerCase();
    const userId = user.id;

    if (isDev) {
      debugInfo.email = userEmail;
      debugInfo.userMetadataRole = user.user_metadata?.role;
      debugInfo.appMetadataRole = user.app_metadata?.role;
    }

    // ========================================
    // 4. 권한 판정 (OR 조건)
    // ========================================
    
    // 4-1. user_metadata.role === "admin"
    const userMetadataRole = user.user_metadata?.role;
    if (userMetadataRole === "admin") {
      console.log(`[checkAdminAuth] ✅ Admin granted via user_metadata.role: ${userEmail} (${authMethod})`);
      return {
        isAdmin: true,
        userId,
        email: userEmail,
        reason: "user_metadata_role",
        authMethod,
        debug: isDev ? debugInfo : undefined,
      };
    }

    // 4-2. app_metadata.role === "admin"
    const appMetadataRole = user.app_metadata?.role;
    if (appMetadataRole === "admin") {
      console.log(`[checkAdminAuth] ✅ Admin granted via app_metadata.role: ${userEmail} (${authMethod})`);
      return {
        isAdmin: true,
        userId,
        email: userEmail,
        reason: "app_metadata_role",
        authMethod,
        debug: isDev ? debugInfo : undefined,
      };
    }

    // 4-3. ADMIN_EMAIL_ALLOWLIST에 포함
    const allowlist = getAdminEmailAllowlist();
    
    if (isDev) {
      debugInfo.allowlist = allowlist;
      debugInfo.allowlistCount = allowlist.length;
      debugInfo.emailInAllowlist = allowlist.includes(userEmail || "");
    }

    if (userEmail && allowlist.includes(userEmail)) {
      console.log(`[checkAdminAuth] ✅ Admin granted via allowlist: ${userEmail} (${authMethod})`);
      return {
        isAdmin: true,
        userId,
        email: userEmail,
        reason: "email_allowlist",
        authMethod,
        debug: isDev ? debugInfo : undefined,
      };
    }

    // ❌ 관리자 권한 없음
    console.warn(`[checkAdminAuth] ❌ Denied: ${userEmail} (no admin role, not in allowlist, method: ${authMethod})`);
    return {
      isAdmin: false,
      userId,
      email: userEmail,
      authMethod,
      error: "not_admin",
      debug: isDev ? debugInfo : undefined,
    };
  } catch (error: any) {
    console.error("[checkAdminAuth] Error:", error.message);
    return {
      isAdmin: false,
      error: error.message,
      debug: isDev ? { ...debugInfo, exception: error.message } : undefined,
    };
  }
}

/**
 * ✅ 관리자 권한 확인 (간단 버전)
 * 
 * @param request NextRequest (optional)
 * @returns boolean
 */
export async function isAdmin(request?: any): Promise<boolean> {
  const result = await checkAdminAuth(request);
  return result.isAdmin;
}
